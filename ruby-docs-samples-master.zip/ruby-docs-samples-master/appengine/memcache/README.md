# Memcached sample for Google App Engine flexible environment

This sample demonstrates accessing Memcached from Ruby on
[Google App Engine flexible environment](https://cloud.google.com/appengine/docs/flexible/).

## Running locally

Refer to the [appengine/README.md](../README.md) file for instructions on
running and deploying.
