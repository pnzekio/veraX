# Metadata server sample for Google App Engine flexible environment

This sample demonstrates reading values from the
[Compute Engine metadata server](https://cloud.google.com/compute/docs/metadata)
from Ruby on
[Google App Engine flexible environment](https://cloud.google.com/appengine/docs/flexible/).

## Running locally

Refer to the [appengine/README.md](../README.md) file for instructions on
running and deploying.
