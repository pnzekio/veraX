require 'sinatra'
require 'redis'

get '/' do
  'Hello world!'
end

get '/redis' do
  Redis.new(password: ENV.fetch('REDIS_PW')).tap do |redis|
    @info = redis.info
    @info['password_set'] = redis.config(:get, :requirepass)['requirepass'] != ''
  end
  erb :index
end
