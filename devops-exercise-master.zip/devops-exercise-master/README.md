# DevOps Candidate Exercise

## Goal
The goal is to deploy a Ruby app to a cloud server (which will be provided), such that its two endpoints are accessible. The app is contained in this repository.

This is a simple ruby app with two endpoints:
  1. Root (`/`) just returns 'Hello world!'
  2. `/redis` returns out the output of Redis `info` command for a Redis server running on the same machine.

You will be provided with a clean Ubuntu 16.04 cloud server, as well as root credentials for said server. (You may request a different linux flavor if you wish; anything Digital Ocean supports).

You may ask clarifying questions while working on this; email or call Jeff Fraser. Come to the interview prepared to discuss this project.

## What to Produce
We want to see any modifications/additions you make to this repo/app, as well as any other files you produce (e.g., your server provisioning materials).

Do not open pull requests against this repo. Instead, send a zip file with your results, or use another private github/bitbucket repository.

## Requirements
* The server is a fresh build. You will need to install and configure any necessary libraries yourself.
* Your strategy for setting up the server should be sustainable and repeatable.
* Redis will need to be installed and configured with a password for the `/redis` endpoint in this app to work. The password must be read out of the `REDIS_PW` environment variable.

## Notes
Here at Veracross, we use the following:

* [nginx](http://nginx.org/) web server
* [Phusion Passenger](https://www.phusionpassenger.com/) to run Ruby apps in nginx
* [Ansible](https://docs.ansible.com/ansible/index.html) to provision servers
* [Capistrano](http://capistranorb.com/) for deployment

However, you are free to choose the stack you are comfortable in. (In other words, it's fine to use Puppet and Unicorn, or whatever else).

## Resources

* [Redis](https://redis.io)
* [Sinatra](http://www.sinatrarb.com/) (this is a Sinatra app)

## Tips
To run this app locally in development, you must have ruby installed. Then:

```
$ cd path/to/this/repo
$ gem install bundler
$ bundle
$ bundle exec ruby server.rb
```

The root URL will work before you have Redis installed. Consider doing this in phases, where Phase 1 gets the root URL working, and Phase 2 gets the `/redis` endpoint working.
